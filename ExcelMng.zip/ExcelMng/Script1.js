{
"TableName": "REG02BD0703FF",
    "Item": {
	    "thingid": {
            "S": "$context.requestId"
            },
        "regtime": {
            "N": "$input.path('$.regtime')"
        },
        "IDwifi": {
            "S": "$input.path('$.IDwifi')"
        },
        "IDcell": {
            "S": "$input.path('$.IDcell')"
            },
        "ISActive": {
            "S": "$input.path('$.ISActive')"
        },
        "PASWifi": {
            "S": "$input.path('$.PASWifi')"
        },
        "SSIDWifi": {
            "S": "$input.path('$.SSIDWifi')"
        },
        "TickTime": {
            "N": $input.path('$.TickTime')
        }
    }
}

{
    "thingid": "CY8V03D00002",
    "regtime": 1544324448450,
    "IDwifi": "C47F51016111",
    "IDcell": "352613070085111",
    "ISActive": "WiFi",
    "PASWifi": "myPass",
    "SSIDWifi": "mySSID",
    "TickTime": 15
}

