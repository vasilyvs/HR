﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelMng.Models
{
    public class ListDoc
    {
        public string NameDoc { get; set; }
        public bool Included { get; set; }
        public bool IsTheFirst { get; set; }
    }
}
