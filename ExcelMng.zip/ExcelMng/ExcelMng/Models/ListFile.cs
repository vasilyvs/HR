﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelMng.Models
{
    public class ListFile
    {
        public string FileName { get; set; }
        public int NumList { get; set; }
        public string ListName { get; set; }
    }
}
