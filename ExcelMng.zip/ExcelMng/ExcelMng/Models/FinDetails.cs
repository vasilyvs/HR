﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelMng.Models
{
    public class FinDetails
    {
        public string FileName { get; set; }
        public string Symbol { get; set; }
        public string Name { get; set; }
        public int Value { get; set; }
        public int Momentum { get; set; }
        public int Quality { get; set; }
        public int Growth { get; set; }
        public string Alpha { get; set; }
        public string Chg { get; set; }
        public string Mtd { get; set; }
        public string Year { get; set; }
        public string GICSSector { get; set; }
        public string Subindustry { get; set; }
        public string Earnings { get; set; }
        public string Cashflow { get; set; }
        public string Dividend { get; set; }
        public string Price { get; set; }
        public string Size { get; set; }

    }
}
