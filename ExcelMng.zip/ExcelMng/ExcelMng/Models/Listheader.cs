﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelMng.Models
{
    public class ListHeader
    {
        public string Symbol { get; set; }
        public string Name { get; set; }
        public int Value { get; set; }
        public int Momentum { get; set; }
        public int Quality { get; set; }
        public int Growth { get; set; }
        public string Alpha { get; set; }
        public string PrevFile1 { get; set; }
        public int Prev1 { get; set; }
        public string PrevFile2 { get; set; }
        public int Prev2 { get; set; }
        public string PrevFile3 { get; set; }
        public int Prev3 { get; set; }
        public string PrevFile4 { get; set; }
        public int Prev4 { get; set; }
        public string PrevFile5 { get; set; }
        public int Prev5 { get; set; }
        public string chg { get; set; }
        public string mtd { get; set; }
        public string Year { get; set; }
        public string GICSSector { get; set; }
        public string Subindustry { get; set; }
        public string Earnings { get; set; }
        public string Cashflow { get; set; }
        public string Dividend { get; set; }
        public string Price { get; set; }
        public string Size { get; set; }
    }
}
