﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelMng.Models
{
    public class FinDoc
    {
        public string FileName { get; set; }
        public DateTime LastDate { get; set; }
        public bool IsMain { get; set; }
        public bool InList { get; set; }
    }
}
