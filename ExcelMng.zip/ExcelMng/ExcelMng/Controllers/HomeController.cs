﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using ExcelMng.Models;
using NPOI.XWPF.UserModel;
using NPOI.OpenXmlFormats.Shared;
using System.IO;
using NPOI.SS.UserModel;
using NPOI.OpenXml4Net.OPC;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;
using ICell = NPOI.XWPF.UserModel.ICell;
using System.Data;

namespace ExcelMng.Controllers
{

    public class HomeController : Controller
    {
        public static List<ListHeader> excelList = new List<ListHeader>();
        public static List<ListHeader> resultList = new List<ListHeader>();
        public static List<ListHeader> mainList = new List<ListHeader>();
        public static List<ListHeader> firstList = new List<ListHeader>();
        public static List<ListHeader> secondList = new List<ListHeader>();
        public static List<ListHeader> thirdList = new List<ListHeader>();
        public static List<ListHeader> fourthList = new List<ListHeader>();
        public static List<ListHeader> fifthList = new List<ListHeader>();          // Max sheets is 5
        public static ListHeader excelString = new ListHeader();
        public static List<FinDetails> detaledList = new List<FinDetails>();        // Max sheets is 5
        public static FinDetails detailedString = new FinDetails();
        public static List<ListFile> fileList = new List<ListFile>();               // matching files and lists
        public static ListFile fileString = new ListFile();


        private XWPFDocument doc = null;
        private string docFile = null;

        private static int SHEET_NUM = 0;
        private static int ROW_NUM = 0;
        private static int CELL_NUM = 0;
        private static double NEW_VALUE = 100.98D;
        private static String BINARY_EXTENSION = "xls";
        private static String OPENXML_EXTENSION = "xlsx";

        /// <summary>
        /// Create simple doc file
        /// </summary>
        public void SimpleTable()
        {
            XWPFDocument doc = new XWPFDocument();
            XWPFParagraph para = doc.CreateParagraph();
            XWPFRun r0 = para.CreateRun();
            r0.SetText("Title1");
            para.BorderTop = Borders.Thick;
            para.FillBackgroundColor = "EEEEEE";
            para.FillPattern = NPOI.OpenXmlFormats.Wordprocessing.ST_Shd.diagStripe;

            XWPFTable table = doc.CreateTable(3, 3);

            table.GetRow(1).GetCell(1).SetText("EXAMPLE OF TABLE");

            XWPFTableCell c1 = table.GetRow(0).GetCell(0);
            XWPFParagraph p1 = c1.AddParagraph();   //don't use doc.CreateParagraph
            XWPFRun r1 = p1.CreateRun();
            r1.SetText("The quick brown fox");
            r1.IsBold = true;

            r1.FontFamily = "Courier";
            r1.SetUnderline(UnderlinePatterns.DotDotDash);
            r1.SetTextPosition(100);
            c1.SetColor("FF0000");


            table.GetRow(2).GetCell(2).SetText("only text");

            FileStream out1 = new FileStream("simpleTable.docx", FileMode.Create);
            doc.Write(out1);
            out1.Close();
        }

        /// <summary>
        /// Simple documents
        /// </summary>
        public void CreateSimpleDoc()
        {
            XWPFDocument doc = new XWPFDocument();

            XWPFParagraph p1 = doc.CreateParagraph();
            p1.Alignment = ParagraphAlignment.CENTER;
            p1.BorderBottom = Borders.Double;
            p1.BorderTop = Borders.Double;

            p1.BorderRight = Borders.Double;
            p1.BorderLeft = Borders.Double;
            p1.BorderBetween = Borders.Single;

            p1.VerticalAlignment = TextAlignment.TOP;

            XWPFRun r1 = p1.CreateRun();
            r1.SetText("The quick brown fox");
            r1.IsBold = true;
            r1.FontFamily = "Courier";
            r1.SetUnderline(UnderlinePatterns.DotDotDash);
            r1.SetTextPosition(100);

            XWPFParagraph p2 = doc.CreateParagraph();
            p2.Alignment = ParagraphAlignment.RIGHT;

            //BORDERS
            p2.BorderBottom = Borders.Double;
            p2.BorderTop = Borders.Double;
            p2.BorderRight = Borders.Double;
            p2.BorderLeft = Borders.Double;
            p2.BorderBetween = Borders.Single;

            XWPFRun r2 = p2.CreateRun();
            r2.SetText("jumped over the lazy dog");
            r2.IsStrike = true;
            r2.FontSize = 20;


            XWPFRun r3 = p2.CreateRun();
            r3.SetText("and went away");
            r3.IsStrike = true;
            r3.FontSize = 20;
            r3.Subscript = VerticalAlign.SUPERSCRIPT;
            r3.SetColor("FF0000");

            XWPFParagraph p3 = doc.CreateParagraph();
            p3.IsWordWrap = true;
            p3.IsPageBreak = true;
            p3.Alignment = ParagraphAlignment.BOTH;
            p3.SpacingLineRule = LineSpacingRule.EXACT;
            p3.IndentationFirstLine = 600;

            XWPFRun r4 = p3.CreateRun();
            r4.SetTextPosition(20);
            r4.SetText("To be, or not to be: that is the question: "
                    + "Whether 'tis nobler in the mind to suffer "
                    + "The slings and arrows of outrageous fortune, "
                    + "Or to take arms against a sea of troubles, "
                    + "And by opposing end them? To die: to sleep; ");
            r4.AddBreak(BreakType.PAGE);
            r4.SetText("No more; and by a sleep to say we end "
                    + "The heart-ache and the thousand natural shocks "
                    + "That flesh is heir to, 'tis a consummation "
                    + "Devoutly to be wish'd. To die, to sleep; "
                    + "To sleep: perchance to dream: ay, there's the rub; "
                    + ".......");
            r4.IsItalic = true;
            //This would imply that this break shall be treated as a simple line break, and break the line after that word:

            XWPFRun r5 = p3.CreateRun();
            r5.SetTextPosition(-10);
            r5.SetText("For in that sleep of death what dreams may come");
            r5.AddCarriageReturn();
            r5.SetText("When we have shuffled off this mortal coil,"
                    + "Must give us pause: there's the respect"
                    + "That makes calamity of so long life;");
            r5.AddBreak();
            r5.SetText("For who would bear the whips and scorns of time,"
                    + "The oppressor's wrong, the proud man's contumely,");

            r5.AddBreak(BreakClear.ALL);
            r5.SetText("The pangs of despised love, the law's delay,"
                    + "The insolence of office and the spurns" + ".......");

            FileStream out1 = new FileStream("simple.docx", FileMode.Create);
            doc.Write(out1);
            out1.Close();
        }

        /// <summary>
        /// Create math formula
        /// </summary>
        public void CreateMathFormula()
        {
            XWPFDocument doc = new XWPFDocument();
            var p = doc.CreateParagraph();
            var math = p.CreateOMath();

            var acc = math.CreateAcc();
            acc.AccPr = "¯";
            acc.Element.CreateRun().SetText("X");
            math.CreateRun().SetText("=");
            var f = math.CreateF();
            f.FractionType = ST_FType.bar;
            f.Denominator.CreateRun().SetText("n");
            var nary = f.Numerator.CreateNary().SetSumm();
            nary.Superscript.CreateRun().SetText("n");
            nary.Subscript.CreateRun().SetText("i=1");
            var ssub = nary.Element.CreateSSub();
            ssub.Element.CreateRun().SetText("X");
            ssub.Subscript.CreateRun().SetText("i");

            FileStream out1 = new FileStream("Xavg.docx", FileMode.Create);
            doc.Write(out1);
            out1.Close();
        }

        /// <summary>
        /// 
        /* 
         * Called to update the embedded Excel workbook. As the format and structire 
         * of the workbook are known in advance, all this code attempts to do is
         * write a new value into the first cell on the first row of the first
         * worksheet.Prior to executing this method, that cell will contain the
         * value 1.
         *
         * @throws org.apache.poi.openxml4j.exceptions.OpenXML4JException
         * Rather
         *                             than use the specific classes (HSSF/XSSF) to handle the embedded
         *                             workbook this method uses those defeined in the SS stream. As
         *                             a result, it might be the case that a SpreadsheetML file is
         *                             opened for processing, throwing this exception if that file is
         *                             invalid.
         * @throws java.io.IOException Thrown if a problem occurs in the underlying
         *                             file system.
        */
        /// </summary>
        /// <param name="filename"></param>
        public void UpdateEmbeddedDoc(String filename)
        {
            IWorkbook workbook = null;
            ISheet sheet = null;
            IRow row = null;
            NPOI.SS.UserModel.ICell cell = null;
            PackagePart pPart = null;
            IEnumerator<PackagePart> pIter = null;
            List<PackagePart> embeddedDocs = this.doc.GetAllEmbedds();
            if (embeddedDocs != null && embeddedDocs.Count != 0)
            {
                pIter = embeddedDocs.GetEnumerator();
                while (pIter.MoveNext())
                {
                    pPart = pIter.Current;
                    if (pPart.PartName.Extension.Equals(BINARY_EXTENSION) ||
                            pPart.PartName.Extension.Equals(OPENXML_EXTENSION))
                    {

                        // Get an InputStream from the pacage part and pass that
                        // to the create method of the WorkbookFactory class. Update
                        // the resulting Workbook and then stream that out again
                        // using an OutputStream obtained from the same PackagePart.
                        workbook = WorkbookFactory.Create(pPart.GetInputStream());
                        sheet = workbook.GetSheetAt(SHEET_NUM);
                        row = sheet.GetRow(ROW_NUM);
                        cell = row.GetCell(CELL_NUM);
                        cell.SetCellValue(NEW_VALUE);
                        workbook.Write(pPart.GetOutputStream());
                    }
                }

                // Finally, write the newly modified Word document out to file.
                string file = Path.GetFileNameWithoutExtension(this.docFile) + "tmp" + Path.GetExtension(this.docFile);
                this.doc.Write(new FileStream(file, FileMode.CreateNew));
            }
        }

        /// <summary>
        /// Amazom S3
        /// </summary>
        public class SThreeScan
        {

            public string SbuckName = "finexcel";

            public static AmazonS3Config clientConfig = new AmazonS3Config();
            public static AmazonS3Client sclient;
            public SThreeScan()
            {
                clientConfig.RegionEndpoint = RegionEndpoint.USWest2;
                sclient = new AmazonS3Client("AKIAJACY3RTDS4ZI5RYQ", "dZGxYbXp6YEpJzpT7sCnYJQcv2X9sLHvarn2uZKF", clientConfig);
            }
            public static List<FinDoc> finList = new List<FinDoc>();

            /// <summary>
            /// Send my file to S3
            /// </summary>
            /// <param name="localFilePath"></param>
            /// <param name="bucketName"></param>
            /// <param name="subDirectoryInBucket"></param>
            /// <param name="fileNameInS3"></param>
            /// <returns></returns>
            public bool sendMyFileToS3(string localFilePath, string bucketName, string subDirectoryInBucket, string fileNameInS3)
            {
                // input explained :
                // localFilePath = the full local file path e.g. "c:\mydir\mysubdir\myfilename.zip"
                // bucketName : the name of the bucket in S3 ,the bucket should be alreadt created
                // subDirectoryInBucket : if this string is not empty the file will be uploaded to
                // a subdirectory with this name
                // fileNameInS3 = the file name in the S3

                // create an instance of IAmazonS3 class ,in my case i choose RegionEndpoint.EUWest1
                // you can change that to APNortheast1 , APSoutheast1 , APSoutheast2 , CNNorth1
                // SAEast1 , USEast1 , USGovCloudWest1 , USWest1 , USWest2 . this choice will not
                // store your file in a different cloud storage but (i think) it differ in performance
                // depending on your location

                // create a TransferUtility instance passing it the IAmazonS3 created in the first step
                TransferUtility utility = new TransferUtility(sclient);
                // making a TransferUtilityUploadRequest instance
                TransferUtilityUploadRequest request = new TransferUtilityUploadRequest();

                if (subDirectoryInBucket == "" || subDirectoryInBucket == null)
                {
                    request.BucketName = bucketName; //no subdirectory just bucket name
                }
                else
                {   // subdirectory and bucket name
                    request.BucketName = bucketName + @"/" + subDirectoryInBucket;
                }
                request.Key = fileNameInS3; //file name up in S3
                request.FilePath = localFilePath; //local file name
                utility.Upload(request); //commensing the transfer

                return true; //indicate that the file was sent
            }


            /// <summary>
            /// Read file from S3 backet and put it to "filePath"
            /// </summary>
            public void ReadingAnObject(string filePath, string objKey)
            {
                var request = new GetObjectRequest()
                {
                    BucketName = SbuckName,
                    Key = objKey
                };
                var cancelToken = new System.Threading.CancellationToken();
                var response = sclient.GetObjectAsync(request);

                bool bstr = false;
                // Save file to local path
                if (filePath.Length != 0)
                    response.Result.WriteResponseStreamToFileAsync(filePath, bstr, cancelToken);
            }

            public void DownloadingAnObject()
            {
                string pathFile = @"D:\Dec18_4.xlsx";
                PutObjectRequest request = new PutObjectRequest
                {
                    Key = pathFile,
                    //InputStream = FileStream,
                    BucketName = "thermacodata",
                    CannedACL = S3CannedACL.PublicRead,
                    StorageClass = S3StorageClass.Standard
                };

                sclient.PutObjectAsync(request);
                sclient.Dispose();
            }

            /// <summary>
            /// List sheets in the bucket
            /// </summary>
            public void ListingSheets()
            {
                try
                {
                    ListObjectsRequest request = new ListObjectsRequest();
                    request.BucketName = SbuckName;
                    var response = sclient.ListObjectsAsync(request);
                    finList = new List<FinDoc>();
                    finList.Clear();
                    foreach (S3Object entry in response.Result.S3Objects)
                    {
                        FinDoc finRec = new FinDoc
                        {
                            FileName = entry.Key.ToString(),
                            LastDate = entry.LastModified

                        };
                        finList.Add(finRec);
                        //Console.WriteLine("key = {0} size = {1}", entry.Key, entry.Size);
                    }

                }
                catch (AmazonS3Exception amazonS3Exception)
                {
                    if (amazonS3Exception.ErrorCode != null && (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId") || amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                    {
                        Console.WriteLine("Please check the provided AWS Credentials.");
                        Console.WriteLine("If you haven't signed up for Amazon S3, please visit http://aws.amazon.com/s3");
                    }
                    else
                    {
                        Console.WriteLine("An error occurred with the message '{0}' when listing objects", amazonS3Exception.Message);
                    }
                }
            }

            public void DeletingAnObject(string objName)
            {
                try
                {
                    DeleteObjectRequest request = new DeleteObjectRequest()
                    {
                        BucketName = SbuckName,
                        Key = objName
                    };

                    sclient.DeleteObjectAsync(request);
                }
                catch (AmazonS3Exception amazonS3Exception)
                {
                    if (amazonS3Exception.ErrorCode != null &&
                        (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId") ||
                        amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                    {
                        Console.WriteLine("Please check the provided AWS Credentials.");
                        Console.WriteLine("If you haven't signed up for Amazon S3, please visit http://aws.amazon.com/s3");
                    }
                    else
                    {
                        Console.WriteLine("An error occurred with the message '{0}' when deleting an object", amazonS3Exception.Message);
                    }
                }
            }

            /// <summary>
            /// Escel to memory
            /// </summary>
            /// <param name="keySheet" S3 file to read></param>
            /// <param name="numList" list number to write. There are restricted number (5 for begin)></param>
            /// <returns></returns>
            public void GetSheetRow(string keySheet,int numList)
            {
                DataTable dt = new DataTable();
                MemoryStream stream = new MemoryStream();
                IWorkbook workbook = null;
                var request = new GetObjectRequest()
                {
                    BucketName = SbuckName,
                    Key = keySheet
                };
                var response = sclient.GetObjectAsync(request);
                response.Result.ResponseStream.CopyTo(stream);
                stream.Position = 0;
                workbook = new XSSFWorkbook(stream);
                ISheet sheet = workbook.GetSheetAt(0);
                var headerRow = sheet.GetRow(0);
                System.Collections.IEnumerator rows = sheet.GetRowEnumerator();
                int cellCount = headerRow.LastCellNum;
                int rowCount = sheet.LastRowNum;
                int rowBegin = sheet.FirstRowNum;
                string hR = headerRow.GetCell(5).ToString();
                ListFile matchLFile = new ListFile();
                for (int i = (rowBegin + 1); i < (rowCount+1); i++)
                {
                    IRow row = sheet.GetRow(i);
                    if (row.GetCell(0).ToString() != "")
                    {
                        ListHeader Lsh = new ListHeader();
                        Lsh.Symbol = row.GetCell(0).ToString();
                        Lsh.Name = row.GetCell(1).ToString();
                        Lsh.Value = (int)Math.Round(Convert.ToDecimal(row.GetCell(2).ToString()));
                        Lsh.Momentum = (int)Math.Round(Convert.ToDecimal(row.GetCell(3).ToString()));
                        Lsh.Quality = (int)Math.Round(Convert.ToDecimal(row.GetCell(4).ToString()));
                        Lsh.Growth = (int)Math.Round(Convert.ToDecimal(row.GetCell(5).ToString()));
                        Lsh.Alpha = row.GetCell(6).ToString();
                        Lsh.chg = row.GetCell(7).ToString();
                        Lsh.mtd = row.GetCell(8).ToString();
                        Lsh.Year = row.GetCell(9).ToString();
                        Lsh.GICSSector = row.GetCell(10).ToString();
                        Lsh.Subindustry = row.GetCell(11).ToString();
                        Lsh.Earnings = row.GetCell(12).ToString();
                        Lsh.Cashflow = row.GetCell(13).ToString();
                        Lsh.Dividend = row.GetCell(14).ToString();
                        Lsh.Price = row.GetCell(15).ToString();
                        Lsh.Size = row.GetCell(16).ToString();
                        // Add filename to the match-list
                        switch (numList)
                        {
                            case 0: mainList.Add(Lsh); break;
                            case 1: firstList.Add(Lsh); break;
                            case 2: secondList.Add(Lsh); break;
                            case 3: thirdList.Add(Lsh); break;
                            case 4: fourthList.Add(Lsh); break;
                            case 5: fifthList.Add(Lsh); break;
                        }
                    }
                }
                //if (numList != 0)
                //{
                    string stFname = keySheet;
                    int found = stFname.IndexOf("/");
                    // remove folder name
                    if (found > 0) stFname = stFname.Substring(found + 1);
                    // rmove extension
                    found = stFname.IndexOf(".");
                    if (found > 0) stFname = stFname.Substring(0, found);
                    // Add file name and Alpha for these columns
                    matchLFile.FileName = stFname;
                    matchLFile.NumList = numList;
                    fileList.Add(matchLFile);
                //}
            }
        }


        protected void btnUploadClick(object sender, EventArgs e)
        {
            string file = Path.GetFileNameWithoutExtension("myFile");
            //HttpPostedFile file = Request.Files["myFile"];

            //check file was submitted
            if (file != null)
            {
                //string fname = Path.GetFileName(file.FileName);
                //file.SaveAs(Server.MapPath(Path.Combine("~/App_Data/", fname)));
            }
        }

        /// <summary>
        /// Tabs menue
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Sdelete(string idDoc)
        {
            SThreeScan fileScan = new SThreeScan();
            var fList = new FinDoc();
            fileScan.ListingSheets();
            var mainID = SThreeScan.finList.Where(s => s.FileName == idDoc).FirstOrDefault();
            return View(mainID);
        }

        [HttpPost]
        public IActionResult Sdelete(FinDoc finDoc)
        {
            string fileToBackup = finDoc.FileName;
            //string myBucketName = "finexcel/findir";
            //string s3DirectoryName = "findir";
            //string sfile = Path.GetFileNameWithoutExtension(idDoc);
            //string s3FileName = @sfile + ".xlsx";
            string extfile = Path.GetExtension(fileToBackup);
            if (extfile == ".xlsx")
            {
                SThreeScan myRemover = new SThreeScan();
                myRemover.DeletingAnObject(fileToBackup);
                ViewBag.ErrorMessage = "File " + fileToBackup + " was successfully removed from S3 storage!";
            }
            else ViewBag.ErrorMessage = "This is not Excell file!!!";
            return RedirectToAction("Sstorage");
        }

        /// <summary>
        /// Create a workplace - list of documents to processing
        /// </summary>
        /// <param name="idDoc" - main document's name></param>
        /// <returns></returns>
        public IActionResult Sworkplace(string idDoc)
        {
            SThreeScan fileScan = new SThreeScan();
            var fList = new FinDoc();
            fileScan.ListingSheets();
            mainList.Clear();
            firstList.Clear();
            secondList.Clear();
            thirdList.Clear();
            fourthList.Clear();
            fifthList.Clear();

            if (idDoc != null)
            {
                var mainID = SThreeScan.finList.Where(s => s.FileName == idDoc).FirstOrDefault();
                mainID.IsMain = true;
                fileList.Clear();
                // get excel data from memory for main findoc
                fileScan.GetSheetRow(idDoc,0);
                // Get excel data from memory for 5 (or less) findocs
                int i = 1;
                foreach (FinDoc dItem in SThreeScan.finList.ToList())
                {
                    // Load to lists all additional files names to put them to list
                    if ((dItem.FileName != idDoc) && (i <= 5))
                    {
                        fileScan.GetSheetRow(dItem.FileName, i); i++;
                    } 
                }
            }


            return View(SThreeScan.finList.AsEnumerable());
        }

        public IActionResult Sdetails(string idRec)
        {
            excelList.Clear();
            //ListHeader mainSelect = resultList.Find(x => x.Symbol.Contains(idRec));
            ListHeader mainSelect = mainList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListHeader firstSelect = firstList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListHeader secondSelect = secondList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListHeader thirdSelect = thirdList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListHeader fourthSelect = fourthList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListHeader fifthSelect = fifthList.Where(s => s.Symbol == idRec).FirstOrDefault();
            ListFile matchFound;
            // make list for one client from 1-5 sheets
            if (mainSelect != null)
            {
                matchFound = fileList.Find(x => (x.NumList == 0));
                mainSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(mainSelect);
            }

            if (firstSelect != null) 
            {
                matchFound = fileList.Find(x => (x.NumList == 1));
                firstSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(firstSelect);
            }

            if (secondSelect != null) 
            {
                matchFound = fileList.Find(x => (x.NumList == 2));
                secondSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(secondSelect);
            }

            if (thirdSelect != null) 
            {
                matchFound = fileList.Find(x => (x.NumList == 3));
                thirdSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(thirdSelect);
            }

            if (fourthSelect != null) 
            {
                matchFound = fileList.Find(x => (x.NumList == 3));
                fourthSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(fourthSelect);
            }

            if (fifthSelect != null) 
            {
                matchFound = fileList.Find(x => (x.NumList == 3));
                fifthSelect.PrevFile1 = matchFound.FileName;
                excelList.Add(fifthSelect);
            }
            return View(excelList.AsEnumerable());

        }

        /// <summary>
        /// Create a table for changed "Alpha" values
        /// </summary>
        /// <returns></returns>
        public IActionResult Sprocess()
        {
            if (mainList.Capacity != 0)
            {
                ListHeader selectedItem = new ListHeader();
                resultList.Clear();
                // Define coices using "Alpha" data as the base
                string stFname = "";
                int found = 0;
                // Obtaining first list and add records to end-list if Alpha is changed
                foreach (ListHeader mainItem in mainList)
                {
                    if (firstList.Capacity != 0)
                    {
                        ListHeader firstFound = firstList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                        if (firstFound != null)
                        {
                            // Match file name to each list
                            ListFile matchFound = fileList.Find(x => (x.NumList == 1));
                            if (matchFound != null)
                            {
                                // Add file name and Alpha for these columns
                                mainItem.PrevFile1 = matchFound.FileName;
                                mainItem.Prev1 = (int)Convert.ToInt16(firstFound.Alpha);
                            }
                            // Check does exist this record in end-list
                            ListHeader isSelected = resultList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                            if (isSelected != null)
                            {
                                // exists
                                resultList[resultList.FindIndex(ind => ind.Equals(isSelected))] = mainItem;
                            } else if (firstFound.Alpha != mainItem.Alpha) resultList.Add(mainItem);                // add string to output list
                        }
                    }
                    if (secondList.Capacity != 0)
                    {
                        ListHeader secondFound = secondList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                        if (secondFound != null)
                        {
                            // Match file name to each list
                            ListFile matchFound = fileList.Find(x => (x.NumList == 2));
                            if (matchFound != null)
                            {
                                // Add file name and Alpha for these columns
                                mainItem.PrevFile2 = matchFound.FileName;
                                mainItem.Prev2 = (int)Convert.ToInt16(secondFound.Alpha);
                            }
                            // Check does exist this record in end-list
                            ListHeader isSelected = resultList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                            if (isSelected != null)
                            {
                                // exists
                                resultList[resultList.FindIndex(ind => ind.Equals(isSelected))] = mainItem;
                            }
                            else if (secondFound.Alpha != mainItem.Alpha) resultList.Add(mainItem);                // add string to output list
                        }
                    }
                    if (thirdList.Capacity != 0)
                    {
                        ListHeader thirdFound = thirdList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                        if (thirdFound != null)
                        {
                            // Match file name to each list
                            ListFile matchFound = fileList.Find(x => (x.NumList == 3));
                            if (matchFound != null)
                            {
                                // Add file name and Alpha for these columns
                                mainItem.PrevFile2 = matchFound.FileName;
                                mainItem.Prev2 = (int)Convert.ToInt16(thirdFound.Alpha);
                            }
                            // Check does exist this record in end-list
                            ListHeader isSelected = resultList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                            if (isSelected != null)
                            {
                                // exists
                                resultList[resultList.FindIndex(ind => ind.Equals(isSelected))] = mainItem;
                            }
                            else if (thirdFound.Alpha != mainItem.Alpha) resultList.Add(mainItem);                // add string to output list
                        }
                    }
                    if (fourthList.Capacity != 0)
                    {
                        ListHeader fourthFound = fourthList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                        if (fourthFound != null)
                        {
                            // Match file name to each list
                            ListFile matchFound = fileList.Find(x => (x.NumList == 3));
                            if (matchFound != null)
                            {
                                // Add file name and Alpha for these columns
                                mainItem.PrevFile2 = matchFound.FileName;
                                mainItem.Prev2 = (int)Convert.ToInt16(fourthFound.Alpha);
                            }
                            // Check does exist this record in end-list
                            ListHeader isSelected = resultList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                            if (isSelected != null)
                            {
                                // exists
                                resultList[resultList.FindIndex(ind => ind.Equals(isSelected))] = mainItem;
                            }
                            else if (fourthFound.Alpha != mainItem.Alpha) resultList.Add(mainItem);                // add string to output list
                        }
                    }
                    if (fifthList.Capacity != 0)
                    {
                        ListHeader fifthFound = fifthList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                        if (fifthFound != null)
                        {
                            // Match file name to each list
                            ListFile matchFound = fileList.Find(x => (x.NumList == 3));
                            if (matchFound != null)
                            {
                                // Add file name and Alpha for these columns
                                mainItem.PrevFile2 = matchFound.FileName;
                                mainItem.Prev2 = (int)Convert.ToInt16(fifthFound.Alpha);
                            }
                            // Check does exist this record in end-list
                            ListHeader isSelected = resultList.Find(x => x.Symbol.Contains(mainItem.Symbol));
                            if (isSelected != null)
                            {
                                // exists
                                resultList[resultList.FindIndex(ind => ind.Equals(isSelected))] = mainItem;
                            }
                            else if (fifthFound.Alpha != mainItem.Alpha) resultList.Add(mainItem);                // add string to output list
                        }
                    }
                }
            }
            return View(resultList.AsEnumerable());
        }


        public IActionResult Sstorage()
        {

            SThreeScan fileScan = new SThreeScan();
            var fList = new FinDoc();
            fileScan.ListingSheets();

            return View(SThreeScan.finList.AsEnumerable());
        }

        [HttpPost]
        public IActionResult Sstorage(FinDoc finDoc)
        {
            if (finDoc.IsMain)
            {
                String tempSt = finDoc.FileName;
            }
            return RedirectToAction("Sstorage");
        }


        public IActionResult Supload()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Supload(string myFile)
        {
            //string sfile = Path.GetFileNameWithoutExtension(myFile);
            //CreateSimpleDoc();
            //CreateMathFormula();
            //fileScan.ReadingAnObject("D:/Tsxls.xlsx", "Dec18 _1.xlsx");
            //fileScan.DownloadingAnObject();
            //string fileToBackup = @"d:\Dec18_4.xlsx";
            string fileToBackup = @myFile;
            string myBucketName = "finexcel";
            string s3DirectoryName = "findir";
            string sfile = Path.GetFileNameWithoutExtension(myFile);
            string s3FileName = @sfile+".xlsx";
            string extfile = Path.GetExtension(myFile);
            if (extfile == ".xlsx")
            {
                SThreeScan myUploader = new SThreeScan();
                myUploader.sendMyFileToS3(fileToBackup, myBucketName, s3DirectoryName, s3FileName);
                ViewBag.ErrorMessage = "File " + s3FileName + " was successfully uploaded!";
            } else ViewBag.ErrorMessage = "This is not Excell file!!!";
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
